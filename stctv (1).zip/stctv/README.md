## Selenium TestNG Project
##### Created framework with data provider
clone the project or download as zip

#### Run Test Options
Run the **testng.xml** file

Run using maven command **mvn clean test**

```
country and plan and price data's are reading from excel file as data provider
you can modify the prices in excel sheet (dataFiles/data.xlsx)
```
	