package tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;

public class CountryPriceAndPlansCheck extends TestBase {

	public static XSSFWorkbook workbook;
	public static XSSFSheet worksheet;
	public static DataFormatter formatter = new DataFormatter();

	@DataProvider
	public static Object[][] getData() throws IOException {
		FileInputStream fileInputStream = new FileInputStream("./datafiles/data.xlsx");
		workbook = new XSSFWorkbook(fileInputStream);
		worksheet = workbook.getSheet("Sheet1");
		XSSFRow Row = worksheet.getRow(0);
		int RowNum = worksheet.getPhysicalNumberOfRows();// count my number of Rows
		int ColNum = Row.getLastCellNum(); // get last ColNum
		Object Data[][] = new Object[RowNum - 1][ColNum];
		for (int i = 0; i < RowNum - 1; i++) // Loop work for Rows
		{
			XSSFRow row = worksheet.getRow(i + 1);
			for (int j = 0; j < ColNum; j++) // Loop work for colNum
			{
				if (row == null)
					Data[i][j] = "";
				else {
					XSSFCell cell = row.getCell(j);
					if (cell == null)
						Data[i][j] = ""; // if it get Null value it pass no data
					else {
						String value = formatter.formatCellValue(cell);
						Data[i][j] = value; // This formatter get my all values as string i.e integer, float all type data value
					}
				}
			}
		}
		return Data;
	}
	
	public static WebDriver driver;
	HomePage homePage;
	SoftAssert softAssert = new SoftAssert();
	@Test(dataProvider = "getData")
	public void checkTheCountryPricesAndPlans(String country, String litePrice, String classicPrice, String premiumPrice) {
		System.out.println("Checking for : " + country + " " + litePrice + " " + classicPrice + " " + premiumPrice);
		driver = TestBase.driver;
		homePage = new HomePage(driver);
		homePage.selectTheCountry(country);
		if (country.equalsIgnoreCase("Bahrain")) {
			ArrayList<String> bahrainPrices = homePage.checkBahrainPrices();
			softAssert.assertEquals(bahrainPrices.get(0), litePrice);
			softAssert.assertEquals(bahrainPrices.get(1), classicPrice);
			softAssert.assertEquals(bahrainPrices.get(2), premiumPrice);
		}
		if (country.equalsIgnoreCase("KSA")) {
			ArrayList<String> kasPrices = homePage.checkKSAPrices();
			softAssert.assertEquals(kasPrices.get(0), litePrice);
			softAssert.assertEquals(kasPrices.get(1), classicPrice);
			softAssert.assertEquals(kasPrices.get(2), premiumPrice);
		}
		if (country.equalsIgnoreCase("Kuwait")) {
			ArrayList<String> kuwaitPrices = homePage.checkKuwaitPrices();
			softAssert.assertEquals(kuwaitPrices.get(0), litePrice);
			softAssert.assertEquals(kuwaitPrices.get(1), classicPrice);
			softAssert.assertEquals(kuwaitPrices.get(2), premiumPrice);
		}
		softAssert.assertAll();
	}

}
