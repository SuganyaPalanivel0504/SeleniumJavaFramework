package pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
	public static WebDriver driver;
	
	public HomePage(WebDriver driver) {
		HomePage.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//*[@class='country-current']")
	WebElement countryButton;
	
	public void selectTheCountry(String country) {
		countryButton.click();
		driver.findElement(By.xpath("//*[@id='country-selct']//*[contains(text(),'"+country+"')]")).click();
	}
	
	@FindBy(xpath = "//*[@class='container']//*[@class='plan-section']/div[3]//*[@class='plan-names']//*[@class='price']")
	List <WebElement> priceList;
	
	
	public ArrayList<String> checkBahrainPrices() {
		ArrayList<String> litePriceList = new ArrayList<>();
		for(int a=0; a<3; a++) {
			litePriceList.add(priceList.get(a).getText().replace("Starting from: ", ""));
		}
		return litePriceList;
	}
	
	public ArrayList<String> checkKSAPrices() {
		ArrayList<String> classicPriceList = new ArrayList<>();
		for(int a=0; a<3; a++) {
			classicPriceList.add(priceList.get(a).getText().replace("Starting from: ", ""));
		}
		return classicPriceList;
	}
	
	public ArrayList<String> checkKuwaitPrices() {
		ArrayList<String> premiumPriceList = new ArrayList<>();
		for(int a=0; a<3; a++) {
			premiumPriceList.add(priceList.get(a).getText().replace("Starting from: ", ""));
		}
		return premiumPriceList;
	}
	
	
	
}
